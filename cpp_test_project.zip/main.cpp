#include <iostream>
#include "math_utils.h"
#include "string_utils.h"

int main() {
    std::cout << "Sum: " << add(10, 20) << std::endl;
    std::cout << "Reversed: " << reverseString("Code Optimization") << std::endl;
    return 0;
}
