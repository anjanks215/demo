#pragma once
#include <string>
std::string reverseString(const std::string& s);
