#pragma once
int add(int a, int b);
int slowFactorial(int n);
