#include "math_utils.h"

int add(int a, int b) {
    return a + b;
}

// inefficient factorial for testing optimization
int slowFactorial(int n) {
    if (n <= 1) return 1;
    return n * slowFactorial(n - 1);
}
